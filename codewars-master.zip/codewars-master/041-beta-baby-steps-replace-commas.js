/*
Jon has a string but its where the spaces (' ') should be there are commas (,).

Your task is to help Jon replace the commas with spaces.
*/

function replace (str) {
  return str.replace(/,/g, ' ');
}
